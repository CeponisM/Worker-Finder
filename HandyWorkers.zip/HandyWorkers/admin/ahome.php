<?php
session_start();
include './class/myclass.php';
connection_open();
if(!isset($_SESSION['admin_id']))
{
    header("location:alogin.php");
    
}
if($_POST)
{
    $uname = $_POST['uname'];
    $pwd  = $_POST['pwd'];
    
    
    $q = mysql_query("select * from admin where admin_email='{$uname}' and admin_psswd ='{$pwd}'") or die(mysql_error());
 
    $data = mysql_fetch_row($q);
    
    if($data>0)
    {
  
        $_SESSION['admin_id'] = $data[0];
        $_SESSION['admin_name'] = $data[1];
        
        header("location:ahome.php");
    }else
    {
        echo "<script>alert('Login Fail')</script>";
    }
    
}
?>
<!DOCTYPE html>
<!--[if IE 7]>                  <html class="ie7 no-js" lang="en">     <![endif]-->
<!--[if lte IE 8]>              <html class="ie8 no-js" lang="en">     <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--> <html class="not-ie no-js" lang="en">  <!--<![endif]-->
<head>

	<!-- Basic Page Needs
	================================================== -->
	<meta charset="utf-8">
	<title>Admin Home | Handyman - Job Board HTML Template</title>
	<meta name="description" content="Handyman - Job Board HTML Template - 1.0">
	


	<!-- Mobile Specific Metas
	================================================== -->
	<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0">
	




	
</head>
<body>

	<div class="site-wrapper">

		<!-- Header -->
	<?php
        include './themepart/header-menunew.php';
        ?>
		<!-- Header / End -->


		<!-- Main -->
		<div class="main" role="main" style="background-color:white">

			<!-- Page Heading -->
			<section class="page-heading">
				<div class="container">
					<div class="row" style="padding-right: 340px">
                                            
						<div class="col-md-12">
						<?php
                                                //session_start();
                                                echo "<h1>"; echo"Hey! Welcome Back!!! , ".$_SESSION
                                                ['admin_name']; echo"</h1>";
                                               if(!isset($_SESSION['admin_id']))
                                              {
                                                    header("location:login.php");
                                                }
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo"<h2>"; echo "<a href='achangepass.php'>Change 
Password</a>"; echo"</h2>";


?>	
                                                   <!--<h1>Welcome</h1>-->
						</div>
					</div>
				</div>
			</section>
			<!-- Page Heading / End -->

			<!-- Page Content -->
			<section class="page-content">
				<div class="container">
					
					<div class="row">
						<div class="col-md-6">
                                                <!--  <center>  <img src="man.png" alt="" width="200px"/></center>-->
                                                   
								<form method="POST">
									
									
                                                              <!--  <center><button type="submit" class="btn btn-primary btn-inline">Logout</button>&nbsp; &nbsp; &nbsp;</center>
                                                                  -->      
								
								</form>
							
						</div>
						
					</div>

				</div>
			</section>
			<!-- Page Content / End -->

			<!-- Footer -->
                      
                    
               
							
				
						
			<!-- Footer / End -->
			
		</div>
		<!-- Main / End -->
	</div>
	
	
	
	
	
	<!-- Javascript Files
	================================================== -->
	<script src="vendor/jquery-1.11.0.min.js"></script>
	<script src="vendor/jquery-migrate-1.2.1.min.js"></script>
	<script src="vendor/bootstrap.js"></script>
	<script src="vendor/jquery.flexnav.min.js"></script>
	<script src="vendor/jquery.hoverIntent.minified.js"></script>
	<script src="vendor/jquery.flickrfeed.js"></script>
	<script src="vendor/magnific-popup/jquery.magnific-popup.js"></script>
	<script src="vendor/owl-carousel/owl.carousel.min.js"></script>
	<script src="vendor/jquery.fitvids.js"></script>
	<script src="vendor/jquery.appear.js"></script>
	<script src="vendor/jquery.stellar.min.js"></script>
	<script src="vendor/jquery.countTo.js"></script>

	<!-- Newsletter Form -->
	<script src="vendor/jquery.validate.js"></script>
	<script src="js/newsletter.js"></script>

	<script src="js/custom.js"></script>


	
</body>
</html>