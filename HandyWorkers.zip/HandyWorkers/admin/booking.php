<?php
session_start();
include './class/myclass.php';
connection_open();
if(!isset($_SESSION['admin_id']))
{
    header("location:alogin.php");
    
}
if($_POST)
{
    
    $bdate = $_POST['bdate'];
    $badate = $_POST['badate'];
    $batime = $_POST['batime'];
    $uid = $_POST['uid'];
    $wid = $_POST['wid'];
    $stid = $_POST['stid'];
    $serid = $_POST['sid'];
    $cid = $_POST['cid'];
    
    $q = mysql_query("insert into booking (booking_date,booking_arr_date,booking_arr_time,user_id,worker_id,status_id,service_id,coupon_id) values ('{$bdate}','{$badate}','{$batime}','{$uid}','{$wid}','{$stid}','{$serid}','{$cid}') ") or die(mysql_error());

    
    if($q)
    {

echo    "<script>alert('Record Inserted');</script>";     
        
    }
    
}


?>

<!DOCTYPE html>
<!--[if IE 7]>                  <html class="ie7 no-js" lang="en">     <![endif]-->
<!--[if lte IE 8]>              <html class="ie8 no-js" lang="en">     <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--> <html class="not-ie no-js" lang="en">  <!--<![endif]-->
<head>

	<!-- Basic Page Needs
	================================================== -->
	<meta charset="utf-8">
	<title>Booking | Handy Workers</title>
  

	<!-- Mobile Specific Metas
	================================================== -->
	<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0">
	
	
	
	<!-- CSS
	================================================== -->
	<!-- Base + Vendors CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/fonts/font-awesome/css/font-awesome.css">
	<link rel="stylesheet" href="css/fonts/entypo/css/entypo.css">
	<link rel="stylesheet" href="vendor/owl-carousel/owl.carousel.css" media="screen">
	<link rel="stylesheet" href="vendor/owl-carousel/owl.theme.css" media="screen">
	<link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css" media="screen">
	<link rel="stylesheet" href="vendor/flexslider/flexslider.css" media="screen">
	<link rel="stylesheet" href="vendor/job-manager/frontend.css" media="screen">

	<!-- Theme CSS-->
	<link rel="stylesheet" href="css/theme.css">
	<link rel="stylesheet" href="css/theme-elements.css">
	<link rel="stylesheet" href="css/animate.min.css">

   

  <!-- Head Libs -->
	<script src="vendor/modernizr.js"></script>

	
	<!-- Favicons
	================================================== -->
	<link rel="shortcut icon" href="images/favicons/favicon.ico">
	<link rel="apple-touch-icon" sizes="120x120" href="images/favicons/favicon-120.png">
	<link rel="apple-touch-icon" sizes="152x152" href="images/favicons/favicon-152.png">
	<?php 
        
        include './themepart/header-script.php';
        
        ?>
</head>
<body>

	<div class="site-wrapper">

		<!-- Header -->
                
                <?php 
                
                include './themepart/header-menunew.php';
                
                ?>
		<!-- Header / End -->


		<!-- Main -->
		<div class="main" role="main" style="background-color:white">

			<!-- Page Heading -->
			<section class="page-heading">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<h1>Admin Panel</h1>
						</div>
					</div>
				</div>
			</section>
			<!-- Page Heading / End -->

			<!-- Page Content -->
			<section class="page-content">
				<div class="container">

					<div class="row">
						<div class="content col-md-8">

						 

							<!-- Additional Info Tabs -->
							<div class="tabs">
                                                            <font color="black">
								<!-- Nav tabs -->
								<ul class="nav nav-tabs">
									<li class="active"><a href="#tab1-1" data-toggle="tab">Insert</a></li>
									<li><a href="#tab1-2" data-toggle="tab">Display</a></li>
								</ul>
								<!-- Tab panes -->
								<div class="tab-content">
									<div class="tab-pane fade in active" id="tab1-1">
										<!-- Comments -->
										<div class="comments-wrapper">
										 
										</div>
										<!-- Comments / End -->

										<!-- Comments Form -->
										<div id="respond" class="comment-respond">
											<h3 class="reply-title"> Booking Master Form</h3>
											

                                                                                        <form action="#" method="POST" name="myform" role="form" style="color: black">
											
												<div class="row">
													<div class="col-md-8">
														<div class="form-group form-grop__icon">
                                                                                                                   <i class="entypo "></i>
                                                                                                                      <strong>  Booking Date :</strong>   <input type="text" name="bdate" required="true" class="form-control" placeholder="Enter Booking Date - YYYY-MM-DD">
														</div>
                                                                                                            <div class="form-group form-grop__icon">
															<i class="entypo "></i>
                                                                                                                         <strong>  Booking Arrival Date :</strong><input type="text" name="badate" required="true" class="form-control" placeholder="Enter Booking Arrival Date - YYYY-MM-DD">
														</div>
                                                                                                              <div class="form-group form-grop__icon">
															<i class="entypo "></i>
                                                                                                                         <strong>  Booking Arrival Time :</strong> <input type="text" name="batime" required="true" class="form-control" placeholder="Enter Booking Arrival Time-HH:MM:SS">
														</div>
                                                                                                                   
                                                                                                            <div class="form-group form-grop__icon">
															<i class="entypo "></i>
                                                                                                                        <strong>User Name :</strong>
                                                                                                                        <br>
                                                                                                                        
                                                                                                                        <?php 
                                                                                                                        
                                                                                                                        
                                                                                                                        $locq  = mysql_query("select * from user") or die(mysql_error());
                                                                                                                        
                                                                                                                        echo "<select name='uid'>";
                                                                                                                        while($locdata = mysql_fetch_array($locq))
                                                                                                                        {
                                                                                                                            
                                                                                                                            echo "<option value='{$locdata[0]}'>$locdata[1]</option>";
                                                                                                                            
                                                                                                                        }
                                                                                                                        
                                                                                                                        echo "</select>";
                                                                                                                        ?>
														</div>
                                                                                                            <div class="form-group form-grop__icon">
															<i class="entypo "></i>
                                                                                                                        <strong> Worker Name :</strong>
                                                                                                                        <br>
                                                                                                                        
                                                                                                                        <?php 
                                                                                                                        
                                                                                                                        
                                                                                                                        $locq  = mysql_query("select * from worker") or die(mysql_error());
                                                                                                                        
                                                                                                                        echo "<select name='wid'>";
                                                                                                                        while($locdata = mysql_fetch_array($locq))
                                                                                                                        {
                                                                                                                            
                                                                                                                            echo "<option value='{$locdata[0]}'>$locdata[1]</option>";
                                                                                                                            
                                                                                                                        }
                                                                                                                        
                                                                                                                        echo "</select>";
                                                                                                                        ?>
														</div>
                                                                                                            <div class="form-group form-grop__icon">
															<i class="entypo "></i>
                                                                                                                        <strong> Status Name :</strong>
                                                                                                                        <br>
                                                                                                                        
                                                                                                                        <?php 
                                                                                                                        
                                                                                                                        
                                                                                                                        $locq  = mysql_query("select * from status") or die(mysql_error());
                                                                                                                        
                                                                                                                        echo "<select name='stid'>";
                                                                                                                        while($locdata = mysql_fetch_array($locq))
                                                                                                                        {
                                                                                                                            
                                                                                                                            echo "<option value='{$locdata[0]}'>$locdata[1]</option>";
                                                                                                                            
                                                                                                                        }
                                                                                                                        
                                                                                                                        echo "</select>";
                                                                                                                        ?>
														</div>
                                                                                                               <div class="form-group form-grop__icon">
															<i class="entypo "></i>
                                                                                                                        <strong>   Service Name :</strong>
                                                                                                                        <br>
                                                                                                                        
                                                                                                                        <?php 
                                                                                                                        
                                                                                                                        
                                                                                                                        $locq  = mysql_query("select * from service") or die(mysql_error());
                                                                                                                        
                                                                                                                        echo "<select name='sid'>";
                                                                                                                        while($locdata = mysql_fetch_array($locq))
                                                                                                                        {
                                                                                                                            
                                                                                                                            echo "<option value='{$locdata[0]}'>$locdata[1]</option>";
                                                                                                                            
                                                                                                                        }
                                                                                                                        
                                                                                                                        echo "</select>";
                                                                                                                        ?>
														</div>
                                                                                                               <div class="form-group form-grop__icon">
															<i class="entypo "></i>
                                                                                                                        <strong>Coupon Name :</strong>
                                                                                                                        <br>
                                                                                                                        
                                                                                                                        <?php 
                                                                                                                        
                                                                                                                        
                                                                                                                        $locq  = mysql_query("select * from coupon") or die(mysql_error());
                                                                                                                        
                                                                                                                        echo "<select name='cid'>";
                                                                                                                        while($locdata = mysql_fetch_array($locq))
                                                                                                                        {
                                                                                                                            
                                                                                                                            echo "<option value='{$locdata[0]}'>$locdata[1]</option>";
                                                                                                                            
                                                                                                                        }
                                                                                                                        
                                                                                                                        echo "</select>";
                                                                                                                        ?>
														</div>
														
														
                                                                                                            	<button type="submit" class="btn btn-primary">Insert Record</button>
										
													</div>
												</div>

												 
												</form>
										</div>
										<!-- Comments Form / End -->
									</div>
									<div class="tab-pane fade" id="tab1-2">
										<div class="row">
											<div class="col-sm-6 col-md-6">
												<?php
                                                                                         
                                                                                         
                                                                                         
                                                                                         if(isset($_GET['delete']))
                                                                                         {
                                                                                             $bid = $_GET['delete'];
                                                                                             $dq = mysql_query("delete  from booking where booking_id ='{$bid}'") or die(mysql_error());
                                                                                             
                                                                                             echo "<script>alert('Reord Delete')</script>";
                                                                                              
                                                                                             
                                                                                         }
                                                                                           $q1=  mysql_query("SELECT
    `booking`.`booking_id`
    , `booking`.`booking_date`
    , `booking`.`booking_arr_date`
    , `booking`.`booking_arr_time`
    , `user`.`user_name`
    , `worker`.`worker_name`
    , `status`.`status_name`
    , `service`.`service_name`
    , `coupon`.`coupon_name`
FROM
    `user`
    INNER JOIN `booking` 
        ON (`user`.`user_id` = `booking`.`user_id`)
    INNER JOIN `worker` 
        ON (`worker`.`worker_id` = `booking`.`worker_id`)
    INNER JOIN `status` 
        ON (`status`.`status_id` = `booking`.`status_id`)
    INNER JOIN `coupon` 
        ON (`coupon`.`coupon_id` = `booking`.`coupon_id`)
    INNER JOIN `service` 
        ON (`service`.`service_id` = `booking`.`service_id`) ORDER BY booking_id") or die(mysql_error());
                                                                                             
                                                                              echo " <table class='job-manager-jobs table table-bordered table-striped'>";
							
                                                                                             //   print_r ($data);
                                                                                             
                                                                              
                                                                                 echo "<thead>";
                                                                                            echo "<tr>";
                                                                                           echo "<th> ID </th>";
                                                                                            echo "<th> Booking Date </th>";
                                                                                           
                                                                                           echo "<th>  Arrival Date  </th>";
                                                                                             echo "<th> Arrival Time</th>";
                                                                                             echo "<th> User Name</th>";
                                                                                             echo "<th> Worker Name</th>";
                                                                                             echo "<th> Status </th>";
                                                                                             echo "<th> Service </th>";
                                                                                             echo "<th> Coupon </th>";
                                                                                             echo "<th> Action </th>";
                                                                                            echo "</tr>";
                                                                                  echo "</thead>";               
                                                                                             while($data = mysql_fetch_array($q1))
                                                                                             {
                                                                                                 echo "<tr>";
                                                                                                 echo "<td>$data[0] </td> <td>$data[1]</td> <td>$data[2]</td> <td>$data[3]</td> <td>$data[4]</td> <td>$data[5]</td> <td>$data[6]</td> <td>$data[7]</td> <td>$data[8]</td> ";
                                                                                               
                                                                                                 echo "<td><a href='booking-edit.php?eid=$data[0]'>Edit </a>| <a href='?delete=$data[0]'>Delete</a> </td>";
                                                                                                 echo "</tr>";
                                                                                             }  
           									echo "</table>";
                                                                                                     ?>
											</div>
											
										</div>
									</div>
								</div>
                                                                </font>
							</div>
							<!-- Additional Info Tabs / End -->

						</div>

						<!-- Sidebar -->
                                                
                                                
					<!-- Sidebar / End -->

					</div>
				</div>
			</section>
			<!-- Page Content / End -->

			<!-- Footer -->
<!-- Footer / End -->
			
		</div>
		<!-- Main / End -->
	</div>
	
	
	
	
	
	<!-- Javascript Files
	================================================== -->
	<script src="vendor/jquery-1.11.0.min.js"></script>
	<script src="vendor/jquery-migrate-1.2.1.min.js"></script>
	<script src="vendor/bootstrap.js"></script>
	<script src="vendor/jquery.flexnav.min.js"></script>
	<script src="vendor/jquery.hoverIntent.minified.js"></script>
	<script src="vendor/jquery.flickrfeed.js"></script>
	<script src="vendor/magnific-popup/jquery.magnific-popup.js"></script>
	<script src="vendor/owl-carousel/owl.carousel.min.js"></script>
	<script src="vendor/jquery.fitvids.js"></script>
	<script src="vendor/jquery.appear.js"></script>
	<script src="vendor/jquery.stellar.min.js"></script>
	<script src="vendor/jquery.countTo.js"></script>

	<!-- Newsletter Form -->
	<script src="vendor/jquery.validate.js"></script>
	<script src="js/newsletter.js"></script>

	<script src="js/custom.js"></script>

	<!-- Google Map -->
	<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
	<script src="vendor/jquery.gmap3.min.js"></script>
	
	<!-- Google Map Init-->
	<script type="text/javascript">
		jQuery(function($){
			$('#map_canvas').gmap3({
				marker:{
					address: '40.717599,-74.005136' 
				},
					map:{
					options:{
					zoom: 17,
					scrollwheel: false,
					streetViewControl : true
					}
				}
		    });
		});
	</script>

<?php

    include './themepart/footer-script.php';

?>



	
</body>
</html>

