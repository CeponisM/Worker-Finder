<?php
session_start();
include './class/myclass.php';
connection_open();

if(!isset($_SESSION['admin_id']))
{
    header("location:alogin.php");
    
}
if($_POST)
{
    $opass = $_POST['opass'];
    $npass = $_POST['npass'];
    $cpass = $_POST['cpass'];
    
    
    $getoldpassq = mysql_query("select * from admin where admin_id='{$_SESSION['admin_id']}'") or die(mysql_error());
    $oldpassfromdb = mysql_fetch_row($getoldpassq);
    
     if($oldpassfromdb[3] == $opass)
     {
         
         if($npass == $cpass)
         {
             
             if($npass==$opass)
             {
                        echo "<script>alert('Old and New Password Must be Different Try Again With New Password');</script>";
  
             }else
             {
                 mysql_query("update admin set admin_psswd ='{$npass}' where admin_id='{$_SESSION['admin_id']}'") or die(mysql_error());
                 
                          echo "<script>alert('Password Updated');</script>";
  
             }
             
         }else
         {
                    echo "<script>alert('New and Confirm Password Not Match');</script>";
  
         }
         
     }else
     {
         echo "<script>alert('Old Password Not Match');</script>";
     }
    
}

?>

<!DOCTYPE html>
<!--[if IE 7]>                  <html class="ie7 no-js" lang="en">     <![endif]-->
<!--[if lte IE 8]>              <html class="ie8 no-js" lang="en">     <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--> <html class="not-ie no-js" lang="en">  <!--<![endif]-->
<head>

	<!-- Basic Page Needs
	================================================== -->
	<meta charset="utf-8">
	<title>Admin Change Password | HandyWorkers</title>
	<meta name="description" content="Handyman - Job Board HTML Template - 1.0">
	


	<!-- Mobile Specific Metas
	================================================== -->
	<meta name="viewport" content="width=device-width,initial-Wscale=1.0,maximum-scale=1.0,user-scalable=0">
	
	
	
	
   

  
	
	
	
</head>
<body>

	<div class="site-wrapper">

		<!-- Header -->
		<?php
                include './themepart/header-menunew.php';
                ?>
		<!-- Header / End -->


		<!-- Main -->
		<div class="main" role="main" style="background-color:white">

			<!-- Page Heading -->
			
                        
                        
			<!-- Page Heading / End -->

			<!-- Page Content -->
			<section class="page-content">
				<div class="container">
					
					<div class="row">
						<div class="col-md-6">
							<div class="box">
								
								<form action="#" method="POST" role="form">
									<div class="form-group">
										<label>Old Password</label>
                                                                                <input type="text" name="opass" class="form-control">
									</div>
									<div class="form-group">
										<label>New Password</label>
                                                                                <input type="text" name="npass" class="form-control">
									</div>
                                                                        <div class="form-group">
                                                                                <label>Confirm New Password</label>
                                                                                <input type="text" name="cpass" class="form-control">
									</div>
                                                                        <button type="submit" class="btn btn-primary btn-inline">Submit</button>&nbsp; &nbsp; &nbsp; 

								</form>
							</div>
						</div>
						
					</div>

				</div>
			</section>
			<!-- Page Content / End -->

			<!-- Footer -->
			<!-- Footer / End -->
			
		</div>
		<!-- Main / End -->
	</div>
	
	
	
	
	
	<!-- Javascript Files
	================================================== -->
	<script src="vendor/jquery-1.11.0.min.js"></script>
	<script src="vendor/jquery-migrate-1.2.1.min.js"></script>
	<script src="vendor/bootstrap.js"></script>
	<script src="vendor/jquery.flexnav.min.js"></script>
	<script src="vendor/jquery.hoverIntent.minified.js"></script>
	<script src="vendor/jquery.flickrfeed.js"></script>
	<script src="vendor/magnific-popup/jquery.magnific-popup.js"></script>
	<script src="vendor/owl-carousel/owl.carousel.min.js"></script>
	<script src="vendor/jquery.fitvids.js"></script>
	<script src="vendor/jquery.appear.js"></script>
	<script src="vendor/jquery.stellar.min.js"></script>
	<script src="vendor/jquery.countTo.js"></script>

	<!-- Newsletter Form -->
	<script src="vendor/jquery.validate.js"></script>
	<script src="js/newsletter.js"></script>

	<script src="js/custom.js"></script>


	
</body>
</html>