<?php


function connection_open()
{
    
    @mysql_connect("localhost","root","") or die("<h1>Error in Connecton open ".mysql_error()." </h1>");
    
    mysql_select_db("project") or die("<h1>Database Selection Problem Check Database Name in PHPMyAdmin ". mysql_error()."</h1>");
            
    
}
