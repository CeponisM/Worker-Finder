<?php
session_start();
include './class/myclass.php';
connection_open();
if(!isset($_SESSION['admin_id']))
{
    header("location:alogin.php");
    
}
if($_POST)
{
    $aname = $_POST['aname'];
    $aemail = $_POST['aemail'];
    $apsswd = $_POST['apsswd'];
    
    $q = mysql_query("insert into admin (admin_name,admin_email,admin_psswd) values ('{$aname}','{$aemail}','{$apsswd}') ") or die(mysql_error());

    
    if($q)
    {

echo    "<script>alert('Record Inserted');</script>";     
        
    }
    
}


?>

<!DOCTYPE html>
<!--[if IE 7]>                  <html class="ie7 no-js" lang="en">     <![endif]-->
<!--[if lte IE 8]>              <html class="ie8 no-js" lang="en">     <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--> <html class="not-ie no-js" lang="en">  <!--<![endif]-->
<head>

	<!-- Basic Page Needs
	================================================== -->
	<meta charset="utf-8">
	<title>Admin | Handy Workers</title>
  

	<!-- Mobile Specific Metas
	================================================== -->
	<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0">
	
	
	
	<!-- Favicons
	================================================== -->
	<link rel="shortcut icon" href="images/favicons/favicon.ico">
	<link rel="apple-touch-icon" sizes="120x120" href="images/favicons/favicon-120.png">
	<link rel="apple-touch-icon" sizes="152x152" href="images/favicons/favicon-152.png">
	
        
</head>
<body>

	<div class="site-wrapper">

		<!-- Header -->
                
                <?php 
                
                include './themepart/header-menunew.php';
                
                ?>
		<!-- Header / End -->


		<!-- Main -->
		<div class="main" role="main" style="background-color:white">

			<!-- Page Heading -->
			<section class="page-heading">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<h1>Admin Panel</h1>
						</div>
					</div>
				</div>
			</section>
			<!-- Page Heading / End -->

			<!-- Page Content -->
			<section class="page-content">
				<div class="container">

					<div class="row">
						<div class="content col-md-8">

						 

							<!-- Additional Info Tabs -->
							<div class="tabs">
                                                            <font color="black">
								<!-- Nav tabs -->
								<ul class="nav nav-tabs">
									<li class="active"><a href="#tab1-1" data-toggle="tab">Insert</a></li>
									<li><a href="#tab1-2" data-toggle="tab">Display</a></li>
								</ul>
								<!-- Tab panes -->
								<div class="tab-content">
									<div class="tab-pane fade in active" id="tab1-1">
										<!-- Comments -->
										<div class="comments-wrapper">
										 
										</div>
										<!-- Comments / End -->

										<!-- Comments Form -->
										<div id="respond" class="comment-respond">
											<h3 class="reply-title"> Admin Master Form</h3>
											

                                                                                        <form action="#" method="POST" name="myform" role="form" style="color:black">
											
												<div class="row">
													<div class="col-md-8">
														<div class="form-group form-grop__icon">
															<i class="entypo "></i>
                                                                                                                        <strong>  Name :</strong><input type="text" name="aname" required="true" class="form-control" placeholder="Enter Admin Name">
														</div>
                                                                                                            <div class="form-group form-grop__icon">
															<i class="entypo "></i>
                                                                                                                        <strong> Email : </strong><input type="text" name="aemail" required="true" class="form-control" placeholder="Enter Admin Email">
														</div>
                                                                                                              <div class="form-group form-grop__icon">
															<i class="entypo "></i>
                                                                                                                        <strong>  Password :</strong><input type="text" name="apsswd" required="true" class="form-control" placeholder="Enter Admin Password">
														
                                                                                                             </div>
                                                                                                                                                                                                           
                                                                                             
                                                                                                            	<button type="submit" class="btn btn-primary">Insert Record</button>
										
													</div>
												</div>

												 
												</form>
										</div>
										<!-- Comments Form / End -->
									</div>
									<div class="tab-pane fade" id="tab1-2">
										<div class="row">
										<?php
                                                                                         
                                                                                         
                                                                                         
                                                                                         if(isset($_GET['delete']))
                                                                                         {
                                                                                             $aid = $_GET['delete'];
                                                                                             $dq = mysql_query("delete  from admin where admin_id ='{$aid}'") or die(mysql_error());
                                                                                             
                                                                                             echo "<script>alert('Reord Delete')</script>";
                                                                                              
                                                                                             
                                                                                         }
                                                                                           $q1=  mysql_query("select * from admin") or die(mysql_error());
                                                                                             
                                                                              echo " <table class='job-manager-jobs table table-bordered table-striped'>";
							
                                                                                             //   print_r ($data);
                                                                                             
                                                                              
                                                                                 echo "<thead>";
                                                                                            echo "<tr>";
                                                                                             echo "<th> ID </th>";
                                                                                            echo "<th> Name </th>";
                                                                                           echo "<th> Email</th>";
                                                                                           echo "<th> Password </th>";
                                                                                           echo "<th> Action </th>";
                                                                                            echo "</tr>";
                                                                                  echo "</thead>";               
                                                                                             while($data = mysql_fetch_array($q1))
                                                                                             {
                                                                                                 echo "<tr>";
                                                                                                 echo "<td>$data[0] </td> <td>$data[1] </td> <td>$data[2]</td> <td>$data[3]</td>";
                                                                                               
                                                                                                 echo "<td><a href='admin-edit.php?eid=$data[0]'>Edit</a> | <a href='?delete=$data[0]'>Delete</a> </td>";
                                                                                                 echo "</tr>";
                                                                                             }  
           									echo "</table>";
                                                                                                     ?>
											
										</div>
									</div>
								</div>
                                                                </font>
							</div>
							<!-- Additional Info Tabs / End -->

						</div>

						<!-- Sidebar -->
					
                                        
                                                    
                                        
                                        <!-- Sidebar / End -->

					</div>
				</div>
			</section>
			<!-- Page Content / End -->

			<!-- Footer -->
                        <!-- Footer / End -->
			
		</div>
		<!-- Main / End -->
	</div>
	
	
	
	
	
	<!-- Javascript Files
	================================================== -->
	<script src="vendor/jquery-1.11.0.min.js"></script>
	<script src="vendor/jquery-migrate-1.2.1.min.js"></script>
	<script src="vendor/bootstrap.js"></script>
	<script src="vendor/jquery.flexnav.min.js"></script>
	<script src="vendor/jquery.hoverIntent.minified.js"></script>
	<script src="vendor/jquery.flickrfeed.js"></script>
	<script src="vendor/magnific-popup/jquery.magnific-popup.js"></script>
	<script src="vendor/owl-carousel/owl.carousel.min.js"></script>
	<script src="vendor/jquery.fitvids.js"></script>
	<script src="vendor/jquery.appear.js"></script>
	<script src="vendor/jquery.stellar.min.js"></script>
	<script src="vendor/jquery.countTo.js"></script>

	<!-- Newsletter Form -->
	<script src="vendor/jquery.validate.js"></script>
	<script src="js/newsletter.js"></script>

	<script src="js/custom.js"></script>

	<!-- Google Map -->
	<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
	<script src="vendor/jquery.gmap3.min.js"></script>
	
	<!-- Google Map Init-->
	<script type="text/javascript">
		jQuery(function($){
			$('#map_canvas').gmap3({
				marker:{
					address: '40.717599,-74.005136' 
				},
					map:{
					options:{
					zoom: 17,
					scrollwheel: false,
					streetViewControl : true
					}
				}
		    });
		});
	</script>

<?php

    include './themepart/footer-script.php';

?>



	
</body>
</html>

